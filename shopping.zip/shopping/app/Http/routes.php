<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/


Route::group(['middleware' => 'web'], function () {
    Route::auth();
    Route::get('/home', 'HomeController@index');
});


Route::group(['middleware' => ['web', 'auth']], function () {
    Route::group(['namespace' => 'Admin', 'prefix' => 'admin'], function () {
        //后台首页
        Route::get('/', 'IndexController@index');

        //商品品牌
        Route::delete('{id}/brand/destroy', 'BrandController@destroy');
        Route::delete('/brand/del_select', 'BrandController@del_select');
        Route::patch('/brand/sort_order', 'BrandController@sort_order');
        Route::patch('/brand/is_show', 'BrandController@is_show');
        Route::resource('brand', 'BrandController');

        //商品分类
        Route::delete('{id}/category/destroy', 'CategoryController@destroy');
        Route::patch('/category/is_show', 'CategoryController@is_show');
        Route::delete('/category/del_select', 'CategoryController@del_select');
        Route::patch('/category/sort_order', 'CategoryController@sort_order');
        Route::resource('category', 'CategoryController');

        //商品列表
        Route::get('search', 'GoodController@search');
        Route::resource('good', 'GoodController');
    });

});


Route::post('/upload', 'FileController@upload');