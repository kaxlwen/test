<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use Cache;
use App\Models\Category;

class CategoryController extends CommonController
{
    function index()
    {
        return view('admin.category.index')->with('categories', Category::get_categories());
    }

    function create()
    {
        return view('admin.category.create')->with('categories', Category::get_categories());
    }

    function store(Request $request)
    {
        Category::create($request->all());
        Cache::forget('admin_category_categories');
        return redirect(route('admin.category.index'))->with('msg', '新增成功！');
    }

    function edit($id)
    {
        $category = Category::find($id);
        $categories = Category::get_categories();
        return view('admin.category.edit')
            ->with('categories', $categories)
            ->with('category', $category);
    }

    function update(Request $request)
    {
        Category::find($request->id)->update($request->all());
        Cache::forget('admin_category_categories');
        return redirect(route('admin.category.index'));
    }

    /*排序*/
    function sort_order(Request $request)
    {
        Category::find($request->id)->update(['sort_order' => $request->sort_order]);
        Cache::forget('admin_category_categories');
    }

    /*是否显示*/
    function is_show(Request $request)
    {
        $category = Category::find($request->id);
        $category->update(['is_show' => $request->is_show]);
    }

    /*多选删除*/
    function del_select(Request $request)
    {
        return $request->all();
//        $del_id = $request->del_id;
//        Category::destroy($del_id);
    }

    /*单选删除*/
    function destroy($id)
    {
        if (count(Category::where("parent_id", "=", "$id")->get())) {
            return redirect('/admin/category')->with('msg', '有子栏目，无法删除！');;
        }
        Category::destroy($id);
        return redirect('/admin/category');
    }


}
