<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use Cache;
use App\Models\Good;
use App\Models\Category;
use App\Models\Brand;

class GoodController extends CommonController
{
    function index()
    {
        $goods = Good::with('category','brand')->get();
//        return $goods;
        return view('admin.good.index')
            ->with('goods',$goods);
    }

    function create()
    {
        return view('admin.good.create')
            ->with('categories', Category::get_categories())
            ->with('brands',Brand::get());
    }

    function search(Request $request)
    {
        $keyword = "%".$request->keyword."%";
        $goods = Good::where("name","like",$keyword)->get();
        return view('admin.good.index')->with('goods',$goods);
    }

    function store(Request $request)
    {
        $a= $request->all();
       return ($a);
    }
}
