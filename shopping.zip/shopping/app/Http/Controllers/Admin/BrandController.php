<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Brand;
use Validator;

class BrandController extends CommonController
{
    //验证错误信息
    private function messages()
    {
        return [
            'name.required' => '品牌名称不能为空！',
            'url.active_url' => '网址格式不对！',
        ];
    }

    function index()
    {
        $brands = Brand::orderBy('sort_order')->get();

        return view('admin.brand.index')->with('brands', $brands);
    }

    function create()
    {
        return view('admin.brand.create');
    }

    function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'url' => 'active_url',
        ], $this->messages());

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        Brand::create($request->all());
        return redirect(route('admin.brand.index'))->with('msg', '新增成功！');
    }

    function edit($id)
    {
        $brand =Brand::find($id);
        return view('admin.brand.edit')->with('brand',$brand);
    }

    function update(Request $request)
    {
       $brand =Brand::find($request->id);
        $brand->update($request->all());
        return redirect(route('admin.brand.index'));
    }
/*排序*/
    function sort_order(Request $request)
    {
        $brand = Brand::find($request->id);
        $brand->update(['sort_order' => $request->sort_order]);
    }
    /*是否显示*/
    function is_show(Request $request)
    {
        $brand = Brand::find($request->id);
        $brand->update(['is_show' => $request->is_show]);
    }
/*多选删除*/
    function del_select(Request $request)
    {
        $del_id = $request->del_id;
        Brand::destroy($del_id);
    }
    /*单选删除*/
    function destroy($id)
    {
        Brand::destroy($id);
        return redirect('/admin/brand');
    }
}
