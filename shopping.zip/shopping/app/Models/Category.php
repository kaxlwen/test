<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Cache;

class Category extends Model
{

    protected $fillable = ['name', 'parent_id', 'thumb', 'desc', 'is_show', 'sort_order'];

    public function goods()
    {
        return $this->hasMany('App\Models\good');
    }
    /*
     * 递归生成无限级分类
     *
     */
   static function get_categories()
   {
        $categories =Cache::rememberforever('admin_category_categories',function(){
            $categories =self::orderBy('parent_id')
                ->orderBy('sort_order')
                ->orderBy('id')
                ->get();
            return tree($categories);
        });
       return $categories;
   }
}
