<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $fillable = ['name', 'url', 'logo', 'desc', 'is_show', 'sort_order'];

    public function goods()
    {
        return $this->hasMany('App\Models\good');
    }

//    static function get_brands()
//    {
//        $brands =Cache::rememberforever('admin_brand_brands',function(){
//            $brands =self::orderBy('parent_id')
//                ->orderBy('sort_order')
//                ->orderBy('id')
//                ->get();
//            return tree($brands);
//        });
//        return $brands;
//    }
}
