@extends('admin.layouts.layout')

@section('css')
    <link rel="stylesheet" href="/assets/select2/css/select2.css"/>
@endsection

@section('content')

    <div class="main-content">
        <div class="breadcrumbs" id="breadcrumbs">
            <script type="text/javascript">
                try {
                    ace.settings.check('breadcrumbs', 'fixed')
                } catch (e) {
                }
            </script>
            <ul class="breadcrumb">
                <li>
                    <i class="icon-home home-icon"></i>
                    <a href="/admin">主页</a>
                </li>

                <li>
                    <a>商品管理</a>
                </li>
                <li style="font-size: larger">商品分类</li>
            </ul>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-xs-8">
                    <!-- PAGE CONTENT BEGINS -->

                    <div class="widget-box">
                        <div class="widget-header">
                            <h4>编辑商品分类</h4>
                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <div class="row">
                                    <form class="form-horizontal" role="form"
                                          action="{{route('admin.category.update',$category->id)}}" method="post">
                                        {!! method_field('put') !!}    {!! csrf_field() !!}
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">
                                                分类名称: </label>

                                            <div class="col-sm-9">
                                                <input type="hidden" value="{{$category->id}}" name="id">
                                                <input type="text" id="form-field-1" value="{{$category->name}}"
                                                       class="col-xs-10 col-sm-5 name" name="name">

                                                <div class="am-hide-sm-only am-u-md-6 name_display"
                                                     style="color: red;display: none">*必填
                                                </div>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">上级分类: </label>
                                            <div class="col-sm-6">
                                                <select name="parent_id" id="select2" class="form-control">
                                                    <option value="0">顶级栏目</option>
                                                    @foreach($categories as $c)
                                                        <option value="{{$c->id}}" data-type="no_add"
                                                            @if($category->parent_id==$c->id) selected @endif>
                                                            {{ blank_to_category($c->count) }}{{$c->name}}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                            <div class="space-4"></div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right"
                                                       for="form-field-1">缩略图: </label>

                                                <div class="col-sm-9">
                                                    <input type="text" style="display: none;" placeholder="上传缩略图"
                                                           value="{{$category->thumb}}"
                                                           class="col-xs-10 col-sm-5" name="thumb" id="img">
                                                    <input type="file" style="display: none;" id="thumb">

                                                    <div class="btn btn-lg btn-success" id="thumb_upload"
                                                         style="float: left;margin-right: 30px">
                                                        <i class="icon-cloud-upload bigger-150" id="loading"></i>upload
                                                    </div>
                                                    <img id="img_show" class="editable img-responsive"
                                                         src="{{$category->thumb}}"
                                                         style="width:200px; height:160px">
                                                </div>
                                            </div>

                                            <div class="space-4"></div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right"
                                                       for="form-field-1">分类描述: </label>
                                                <div class="col-sm-9">
                                                <textarea class="form-control limited col-xs-10 col-sm-5"
                                                          id="form-field-9"
                                                          maxlength="50" name="desc">{{$category->desc}}</textarea>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right"
                                                       for="form-field-1">
                                                    是否显示: </label>

                                                <div class="col-sm-9">
                                                    <label>
                                                        <input class="ace ace-switch ace-switch-5 is_show"
                                                               type="checkbox" data-id="{{$category->id}}"
                                                               @if($category->is_show==1) checked value="1"
                                                                @endif>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="space-4"></div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label no-padding-right"
                                                       for="form-field-1">
                                                    排序: </label>

                                                <div class="col-sm-9">
                                                    <input type="text" id="form-field-1" class="col-xs-10 col-sm-1" value="{{$category->sort_order}}"
                                                           name="sort_order">
                                                </div>
                                            </div>
                                            <div class="clearfix form-actions">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button class="btn" type="reset">
                                                        <i class="icon-undo bigger-110"></i>
                                                        Reset重置
                                                    </button>
                                                    &nbsp; &nbsp; &nbsp;
                                                    <button class="btn btn-info submit" type="submit">
                                                        <i class="icon-ok bigger-110"></i>
                                                        Submit提交
                                                    </button>
                                                </div>
                                            </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection

    @section('js')
            <!-- page specific plugin scripts -->
    <script src="/assets/xshop/jquery.html5-fileupload.js"></script>
    <script src="/assets/xshop/upload.js"></script>
    <script src="/assets/select2/js/select2.js"></script>
    <script type="text/javascript">
        $('#select2').select2();
    </script>
    <script>
        $(function () {
            /*是否显示*/
            $(".is_show").on('click', function () {
                $value = $(this).val();
                if ($value == 1) {
                    $(this).val(0);
                } else {
                    $(this).val(1);
                }
                var info = {
                    id: $(this).data("id"),
                    is_show: $(this).val()
                }
                console.log(info);
                $.ajax({
                    type: 'PATCH',
                    data: info,
                    url: "/admin/category/is_show",
                })
            });
            /*必填项*/
            $(".submit").click(function () {
                $value = $(".name").val();
                if ($value == "") {
                    $(".name_display").attr("style", "color: red;");
                    return false;
                }
            });
            $(".name").blur(function () {
                $value = $(this).val();
                if ($value == "") {
                    $(".name_display").attr("style", "color: red;");
                } else {
                    $(".name_display").attr("style", "color: red;display:none");
                }
            });
        })
    </script>
@endsection
