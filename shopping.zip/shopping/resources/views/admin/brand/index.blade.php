@extends('admin.layouts.layout')

@section('css')
    <style>
        .logo {
            width: 70px;
            height: 35px;
        }
        .line td{
            font-weight: bold;
        }
    </style>
@endsection

@section('content')
    <div class="main-content">
        <div class="breadcrumbs" id="breadcrumbs">
            <script type="text/javascript">
                try {
                    ace.settings.check('breadcrumbs', 'fixed')
                } catch (e) {
                }
            </script>

            <ul class="breadcrumb">
                <li>
                    <i class="icon-home home-icon"></i>
                    <a href="/admin">主页</a>
                </li>

                <li>
                    <a href="">商品管理</a>
                </li>
                <li style="font-size: larger">商品品牌</li>

            </ul>
            <span style="float: right;">

                <a href="{{route('admin.brand.create')}}" class="btn btn-app btn-xs" style="margin: 0;padding: 0">
                    <i class="icon-plus-sign"></i>
                    Add
                </a>
                <a href="" class="btn btn-app btn-xs delete" style="margin: 0;padding: 0" id="del_select">
                    <i class="icon-trash"></i>
                    Delete
                </a>
            </span>

            <!-- .breadcrumb -->
        </div>
        <div class="page-content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->

                    <div class="row">
                        <div class="col-xs-12" style="text-align: center">
                            @include('admin.layouts._msg')

                            <div class="table-responsive">
                                <form id="form">
                                    <table id="sample-table-2" class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr class="line">
                                            <th class="center">
                                                <label>
                                                    <input type="checkbox" class="ace"/>
                                                    <span class="lbl"></span>
                                                </label>
                                            </th>
                                            <th>品牌名称</th>
                                            <td>Logo</td>
                                            <td>描述</th>
                                            <th>排序 </th>
                                            <td class="hidden-480">显示</td>

                                            <td>操作</td>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        @foreach ($brands as $brand)
                                            <tr>
                                                <td class="center">
                                                    <label>
                                                        <input type="checkbox" class="del_id" name="del_id[]"
                                                               value="{{$brand->id}}"/>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </td>
                                                <td>
                                                    <a href="{{$brand->url}}" target="_blank">
                                                      <i class="icon-heart-empty"></i>  {{$brand->name}}
                                                    </a>
                                                </td>
                                                <td style="padding:2px 0px">
                                                    <img src="{{$brand->logo}}" class="logo" style="height: 50px;width: 90px;">
                                                </td>
                                                <td class="hidden-480">{{$brand->desc}}</td>
                                                <td>
                                                    <input value="{{$brand->sort_order}}" data-id="{{$brand->id}}"
                                                           class="sort_order" style="width: 30px;border: none">
                                                </td>

                                                <td class="hidden-480">
                                                    <label>
                                                        <input class="ace ace-switch ace-switch-5 is_show" data-id="{{$brand->id}}" type="checkbox" name="is_show"
                                                               @if($brand->is_show==1) checked="checked" @endif>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </td>

                                                <td>
                                                    <div class="visible-md visible-lg hidden-sm hidden-xs action-buttons">
                                                        <a class="green"
                                                           href="{{route('admin.brand.edit', $brand->id)}}">
                                                            <i class="icon-pencil bigger-130"></i>
                                                        </a>

                                                        <a class="red" href="brand/{{$brand->id}}"
                                                           data-confirm="确认删除当前品牌吗?"
                                                           data-method="delete" data-token="{{csrf_token()}}">
                                                            <i class="icon-trash bigger-130"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.page-content -->
    </div><!-- /.main-content -->
    @endsection

    @section('js')
            <!-- page specific plugin scripts -->

    <script type="text/javascript">
        $(function () {
            $(".sort_order").change(function () {
                var info = {
                    id: $(this).data("id"),
                    sort_order: $(this).val()
                };
                console.log(info);
                $.ajax({
                    type: "PATCH",
                    data: info,
                    url: "/admin/brand/sort_order",
                });
            });
            /*多选删除*/
            $("#del_select").click(function () {
                var length = $('.del_id:checked').length;
                if (length == 0) {
                    alert('您必须至少选择一条记录');
                }

                var values = $("#form").serialize();
                $.ajax({
                    type: "DELETE",
                    data: values,
                    url: "/admin/brand/del_select",
//                    dataType: "json",
                    success: function (data) {
                        location.href = location.href;
                    }
                })
            });

            /*是否显示*/
            $(".is_show").on("click",function(){
                   if($(this).is(':checked')==true){
                       is_show =1;
                   }else{
                       is_show =0;
                   }
                var info = {
                    id: $(this).data("id"),
                    is_show: is_show
                }
                console.log(info);
                $.ajax({
                    type:'PATCH',
                    data:info,
                    url:"/admin/brand/is_show",
                })
            });

            /*图片放大显示*/
            $(".logo").dblclick(function(){
                $(this).attr("style","z-index:1;height: 300px;width: 300px;position:absolute");
            });
            $(".logo").click(function(){
                $(this).attr("style","height: 50px;width: 90px");
            });
        })
    </script>
@endsection