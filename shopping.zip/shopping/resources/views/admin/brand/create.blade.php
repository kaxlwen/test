@extends('admin.layouts.layout')

@section('css')
@endsection

@section('content')

    <div class="main-content">
        <div class="breadcrumbs" id="breadcrumbs">
            <script type="text/javascript">
                try {
                    ace.settings.check('breadcrumbs', 'fixed')
                } catch (e) {
                }
            </script>
            <ul class="breadcrumb">
                <li>
                    <i class="icon-home home-icon"></i>
                    <a href="/admin">主页</a>
                </li>

                <li>
                    <a href="/admin/brand">商品管理</a>
                </li>
                <li style="font-size: larger">商品品牌</li>
            </ul>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-xs-8">
                    <!-- PAGE CONTENT BEGINS -->

                    <div class="widget-box">
                        <div class="widget-header">
                            <h4>添加商品品牌</h4>
                        </div>

                        <div class="widget-body">
                            <div class="widget-main">
                                <div class="row">
                                    @include('admin.layouts._msg')
                                    <form class="form-horizontal" role="form" action="{{route('admin.brand.store')}}" method="post">
                                        {!! csrf_field() !!}
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">品牌名称: </label>
                                            <div class="col-sm-9">
                                                <input type="text" id="form-field-1" placeholder="品牌名称"
                                                       class="col-xs-10 col-sm-5 name" name="name" value="{{old('name')}}">
                                                <div class="am-hide-sm-only am-u-md-6 name_display" style="color: red;display: none">*必填</div>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">
                                                品牌网址: </label>

                                            <div class="col-sm-9">
                                                <input type="text" id="form-field-1" placeholder="品牌网址"
                                                       class="col-xs-10 col-sm-5 url" name="url" value="{{old('url')}}">
                                                <div class="am-hide-sm-only am-u-md-6 url_display" style="color: red;display: none">*必填</div>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">
                                                品牌Logo: </label>

                                            <div class="col-sm-9">
                                                <input type="text" style="display: none;" placeholder="品牌Logo"
                                                       class="col-xs-10 col-sm-5" name="logo" id="img">
                                                <input type="file" style="display: none;" id="thumb">
                                                <div class="btn btn-lg btn-success" id="thumb_upload" style="float: left;margin-right: 30px">
                                                    <i class="icon-cloud-upload bigger-150" id="loading"></i>upload
                                                </div>
                                                <img id="img_show" class="editable img-responsive" src=""
                                                     style="width:200px; height:160px;display:none">
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">品牌描述: </label>
                                            <div class="col-sm-9">
                                                <textarea class="form-control limited col-xs-10 col-sm-5"
                                                          id="form-field-9" maxlength="50" name="desc"></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">是否显示: </label>
                                            <div class="col-sm-9">
                                                <label>
                                                    <input class="ace ace-switch ace-switch-5" type="checkbox" id="is_show"
                                                           name="is_show" checked value="1">
                                                    <span class="lbl"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-1">排序: </label>
                                            <div class="col-sm-9">
                                                <input type="text" id="form-field-1" class="col-xs-10 col-sm-1" value="99" name="sort_order">
                                            </div>
                                        </div>


                                        <div class="clearfix form-actions">
                                            <div class="col-md-offset-3 col-md-9">
                                                <button class="btn" type="reset">
                                                    <i class="icon-undo bigger-110"></i>
                                                    Reset重置
                                                </button>
                                                &nbsp; &nbsp; &nbsp;
                                                <button class="btn btn-info submit" type="submit">
                                                    <i class="icon-ok bigger-110"></i>
                                                    Submit提交
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection

    @section('js')
            <!-- page specific plugin scripts -->
    <script src="/assets/xshop/jquery.html5-fileupload.js"></script>
    <script src="/assets/xshop/upload.js"></script>
    <script>
        $(function(){
            /*是否显示*/
            $(".ace-switch").on('click',function(){
                $value = $("#is_show").val();
                if($value==1){
                    $("#is_show").val(0);
                }else{
                    $("#is_show").val(1);
                }
            });

            /*必填项*/
            $(".submit").click(function(){
                $value = $(".name").val();
                if($value==""){
                    $(".name_display").attr("style","color: red;");
                    return false;
                }
            });
            $(".name").blur(function(){
                $value = $(this).val();
                if($value==""){
                    $(".name_display").attr("style","color: red;");
                }else{
                    $(".name_display").attr("style","color: red;display:none");
                }
            });
            /*网址格式*/
            $(".url").blur(function(){
                $value = $(this).val();
                if($value==""){
                    $(".url_display").attr("style","color: red;");
                }else{
                    $(".url_display").attr("style","color: red;display:none");
                }
            });

        })
    </script>

    @endsection