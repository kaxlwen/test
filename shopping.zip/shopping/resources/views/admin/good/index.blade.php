@extends('admin.layouts.layout')

@section('css')
    <style>
        .logo {
            width: 70px;
            height: 35px;
        }

        .line td {
            font-weight: bold;
        }
    </style>
@endsection

@section('content')
    <div class="main-content">
        <div class="breadcrumbs" id="breadcrumbs">
            <script type="text/javascript">
                try {
                    ace.settings.check('breadcrumbs', 'fixed')
                } catch (e) {
                }
            </script>

            <ul class="breadcrumb">
                <li>
                    <i class="icon-home home-icon"></i>
                    <a href="/admin">主页</a>
                </li>

                <li>
                    <a>商品管理</a>
                </li>
                <li style="font-size: larger">商品列表</li>

            </ul>
            <!-- .breadcrumb -->
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->

                    <div class="row">
                        <div class="col-xs-12" style="text-align: center">
                            @include('admin.layouts._msg')

                            <div class="table-responsive">
                                <div class="widget-box">
                                    <div class="widget-header widget-header-small">
                                        <h5 class="lighter">Add & Search</h5>
                                    </div>
                                    <div class="widget-body">
                                        <div class="widget-main" >
                                            <form class="form-search" action="/admin/search" method="get" >
                                                <div class="row">
                                                    <div class="col-xs-10 col-sm-6">
                                                        <div class="input-group">
                                                                 <span>
                                                                    <a href="{{route('admin.good.create')}}"
                                                                       class="btn btn-sm btn-success bigger-250">
                                                                        <i class="icon-plus-sign"></i>Add
                                                                    </a>
                                                                </span>
                                                                <span class="input-group-btn" >
																		<button type="button submit" class="btn btn-purple btn-sm" >
                                                                            Search
                                                                            <i class="icon-search icon-on-right bigger-110"></i>
                                                                        </button>
																	</span>
                                                            <input type="text" class="form-control search-query" name="keyword"
                                                                   placeholder="请输入关键字!">
                                                        </div>
                                                    </div>
                                                </div>

                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <form id="form">


                                    <table id="sample-table-2" class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr class="line">
                                            <th> 编号</th>
                                            <th>商品名称</th>
                                            <td>缩略图</td>
                                            <th>分类</th>
                                            <th>价格</th>
                                            <td>库存</td>
                                            <td>上架</td>
                                            <td>新品</td>
                                            <td>火爆</td>
                                            <td>推荐</td>
                                            <th>操作</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        @foreach ($goods as $good)
                                            <tr>
                                                <td> {{$good->id}}</td>
                                                <td>
                                                    <a style="text-decoration: none">
                                                        <p>{{$good->name}}</p>
                                                    </a>
                                                </td>
                                                <td>
                                                    <img src="{{$good->thumb}}" class="thumb"
                                                         style="height: 50px;width: 90px;">
                                                </td>
                                                <td>{{$good->brand->name}}{{$good->category->name}}</td>
                                                <td>{{$good->price}}</td>
                                                <td> {{$good->inventory}} </td>
                                                <td class="hidden-480">
                                                    <label>
                                                        <input name="switch-field-1" class="ace ace-switch ace-switch-6"
                                                               data-id="{{$good->is_show}}"
                                                               type="checkbox"
                                                               @if($good->is_show==1) checked="checked" @endif>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </td>
                                                <td class="hidden-480">
                                                    <label>
                                                        <input name="switch-field-1" class="ace ace-switch ace-switch-6"
                                                               type="checkbox"
                                                               @if($good->new==1) checked="checked" @endif>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </td>
                                                <td class="hidden-480">
                                                    <label>
                                                        <input name="switch-field-1" class="ace ace-switch ace-switch-6"
                                                               data-id="{{$good->hot}}"
                                                               type="checkbox"
                                                               @if($good->hot==1) checked="checked" @endif>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label>
                                                        <input name="switch-field-1" class="ace ace-switch ace-switch-6"
                                                               data-id="{{$good->recommend}}"
                                                               type="checkbox"
                                                               @if($good->recommend==1) checked="checked" @endif>
                                                        <span class="lbl"></span>
                                                    </label>
                                                </td>
                                                <td>
                                                    <div class="visible-md visible-lg hidden-sm hidden-xs action-buttons">
                                                        <a class="green"
                                                           href="{{route('admin.good.edit', $good->id)}}">
                                                            <i class="icon-pencil bigger-130"></i>
                                                        </a>

                                                        <a class="red" href="good/{{$good->id}}"
                                                           data-confirm="确认删除当前品牌吗?"
                                                           data-method="delete" data-token="{{csrf_token()}}">
                                                            <i class="icon-trash bigger-130"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.page-content -->
    </div><!-- /.main-content -->
    @endsection

    @section('js')
            <!-- page specific plugin scripts -->

    <script type="text/javascript">

        $(function () {
//            $(".sort_order").change(function () {
//                var info = {
//                    id: $(this).data("id"),
//                    sort_order: $(this).val()
//                };
//                console.log(info);
//                $.ajax({
//                    type: "PATCH",
//                    data: info,
//                    url: "/admin/category/sort_order",
//                });
//            });
//
//            /*是否显示*/
//            $(".is_show").on("click",function(){
//                   if($(this).is(':checked')==true){
//                       is_show =1;
//                   }else{
//                       is_show =0;
//                   }
//                var info = {
//                    id: $(this).data("id"),
//                    is_show: is_show
//                }
//                console.log(info);
//                $.ajax({
//                    type:'PATCH',
//                    data:info,
//                    url:"/admin/category/is_show",
//                })
//            });
//            /*图片放大显示*/
//            $(".thumb").dblclick(function(){
//                $(this).attr("style","z-index:1;height: 300px;width: 300px;position:absolute");
//            });
//            $(".thumb").click(function(){
//                $(this).attr("style","height: 50px;width: 90px");
//            });
        })
    </script>
@endsection