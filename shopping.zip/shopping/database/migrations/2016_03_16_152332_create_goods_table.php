<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGoodsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('goods', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('brand_id');
            $table->integer('category_id');
            $table->string('name');
            $table->integer('invertory');
            $table->char('price');
            $table->text('desc');
            $table->string('thumb');
            $table->boolean('is_show')->default(false);
            $table->boolean('hot')->default(false);
            $table->boolean('new')->default(false);
            $table->boolean('recommend')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
