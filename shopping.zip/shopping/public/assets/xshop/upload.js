//文件上传
$('#thumb_upload').on('click', function () {
    $("#thumb").click();
    $("#img_show").slideDown("slow");
    return false;
});



var opts = {
    url: "/upload",
    type: "POST",
    beforeSend: function () {
        $("#loading").attr('class', 'icon-refresh icon-spin orange bigger-150');
    },
    success: function (result, status, xhr) {
         console.log(result);

        $("#loading").attr('class', 'icon-cloud-upload bigger-150');

        if (result.status == 0) {
            alert(result.info);
            return false;
        }
        $("#img").val(result.info);
        $("#img_show").attr("src", result.info);

    },
    error: function (result, status, errorThrown) {
         //alert(errorThrown)
        $("#loading").attr('class', 'icon-cloud-upload bigger-150');
        alert('文件上传失败');
    }
}
$('#thumb').fileUpload(opts);