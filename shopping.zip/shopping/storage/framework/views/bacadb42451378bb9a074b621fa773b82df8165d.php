点击这里，修改你的密码: <a href="<?php echo e($link = url('/admin/password/reset', $token).'?email='.urlencode($user->getEmailForPasswordReset())); ?>"> <?php echo e($link); ?> </a>
