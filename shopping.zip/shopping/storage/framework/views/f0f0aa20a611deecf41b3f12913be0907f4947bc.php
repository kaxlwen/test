<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/assets/select2/css/select2.css"/>
    <style>
        .tab-pane {
            margin-top: 20px;
        }

        .col-sm-3 {
            width: 18%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content">
        <div class="breadcrumbs" id="breadcrumbs">
            <script type="text/javascript">
                try {
                    ace.settings.check('breadcrumbs', 'fixed')
                } catch (e) {
                }
            </script>
            <ul class="breadcrumb">
                <li>
                    <i class="icon-home home-icon"></i>
                    <a href="/admin">主页</a>
                </li>

                <li>
                    <a>商品管理</a>
                </li>
                <li style="font-size: larger">商品列表</li>
            </ul>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- PAGE CONTENT BEGINS -->

                    <div class="widget-box">
                        <div class="widget-header">
                            <h4>添加新商品</h4>
                        </div>
                        <div class="col-sm-14">

                            <ul class="nav nav-tabs padding-12 tab-color-blue background-blue" id="myTab4">
                                <li class="col-xs-2 active">
                                    <a data-toggle="tab" href="#home4">基本信息</a>
                                </li>

                                <li class="col-xs-2">
                                    <a data-toggle="tab" href="#profile4">Profile</a>
                                </li>

                                <li class="col-xs-2">
                                    <a data-toggle="tab" href="#dropdown14">商品相册</a>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <div id="home4" class="tab-pane active">
                                    <form class="form-horizontal" role="form" action="<?php echo e(route('admin.good.store')); ?>"
                                          method="post">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">商品名称: </label>

                                            <div class="col-sm-9">
                                                <input type="text" id="form-field-1" placeholder="请填入商品名称"
                                                       class="col-xs-10 col-sm-5 name" name="name">

                                                <div class="am-hide-sm-only am-u-md-6 name_display"
                                                     style="color: red;display: none">*必填
                                                </div>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">商品分类: </label>

                                            <div class="col-sm-6">
                                                <select name="category_id" id="select2" class="form-control select">
                                                    <option value="0">请选择分类..</option>
                                                    <?php foreach($categories as $category): ?>
                                                        <option value="<?php echo e($category->id); ?>" data-type="no_add">
                                                            <?php echo e(blank_to_category($category->count)); ?><?php echo e($category->name); ?>

                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">商品品牌: </label>

                                            <div class="col-sm-6">
                                                <select name="brand_id" id="select3" class="form-control">
                                                    <option value="0">请选择品牌..</option>
                                                    <?php foreach($brands as $brand): ?>
                                                        <option value="<?php echo e($brand->id); ?>" data-type="no_add">
                                                            <?php echo e($brand->name); ?>

                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">缩略图: </label>

                                            <div class="col-sm-9">
                                                <input type="text" style="display: none;" placeholder="上传缩略图"
                                                       class="col-xs-10 col-sm-5" name="thumb" id="img">
                                                <input type="file" style="display: none;" id="thumb">

                                                <div class="btn btn-lg btn-success" id="thumb_upload"
                                                     style="float: left;margin-right: 30px">
                                                    <i class="icon-cloud-upload bigger-150" id="loading"></i>upload
                                                </div>
                                                <img id="img_show" class="editable img-responsive" src=""
                                                     style="width:200px; height:160px;display:none">
                                            </div>
                                        </div>

                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1"
                                                   style="margin-right: 12px">商品价格: </label>

                                            <div class="input-group">
                                                <input type="text" class="input-mini spinner-input form-control"
                                                       id="spinner2" maxlength="10">
                                            </div>
                                        </div>

                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1"
                                                   style="margin-right: 12px">库存: </label>

                                            <div class="input-group">
                                                <input type="text" class="input-mini spinner-input form-control"
                                                       id="spinner3" maxlength="4">
                                            </div>
                                        </div>

                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">标签: </label>

                                            <div class="col-sm-9">
                                                <div class="control-group">
                                                    <label class="control-label bolder blue">
                                                        <input name="form-field-checkbox" type="checkbox"
                                                               class="ace ace-checkbox-2">
                                                        <span class="lbl" name="new" value="1">新品</span>
                                                        <input name="form-field-checkbox" type="checkbox"
                                                               class="ace ace-checkbox-2">
                                                        <span class="lbl" name="hot" value="1"> 热品</span>
                                                        <input name="form-field-checkbox" class="ace ace-checkbox-2"
                                                               type="checkbox">
                                                        <span class="lbl" name="recommend" value="1">推荐</span>
                                                    </label>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">是否上架: </label>

                                            <div class="col-sm-9">
                                                <label>
                                                    <input class="ace ace-switch ace-switch-5" type="checkbox"
                                                           id="is_show"
                                                           name="is_show" checked value="1">
                                                    <span class="lbl"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="space-4"></div>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label" for="form-field-1">内容描述: </label>

                                            <div class="col-sm-9">
                                               <textarea id="editor_id" name="content"
                                                         style="width:700px;height:300px;">
                                                </textarea>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <div id="profile4" class="tab-pane">
                                    <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee
                                        squid.</p>
                                </div>

                                <div id="dropdown14" class="tab-pane">
                                    <div class="col-sm-12">
                                        <div class="widget-box">
                                            <div class="widget-header">
                                                <h4>商品相册</h4>
													<span class="widget-toolbar">
														<a href="#" data-action="collapse">
                                                            <i class="icon-chevron-up"></i>
                                                        </a>
														<a href="#" data-action="close">
                                                            <i class="icon-remove"></i>
                                                        </a>
													</span>
                                            </div>

                                            <div class="widget-body">
                                                <div class="widget-body-inner" style="display: block;">
                                                    <div class="widget-main">
                                                        <div class="ace-file-input">
                                                            <input type="file"  id="id-input-file-2">
                                                            <label class="file-label"  data-title="Choose">
                                                                <span class="file-name" data-title="No File ...">
                                                                    <i class="icon-upload-alt"></i>
                                                                </span>
                                                            </label>
                                                            <a class="remove" href="#">
                                                                <i class="icon-remove"></i>
                                                            </a>
                                                        </div>
                                                        <div class="ace-file-input ace-file-multiple" >
                                                            <input multiple="" type="file" id="id-input-file-3">
                                                            <a class="remove" href="#"><i class="icon-remove"></i></a>
                                                        </div>
                                                        <label>
                                                            <input type="checkbox" name="file-format"
                                                                   id="id-file-format" class="ace">
                                                            <span class="lbl"> 只传图片</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix form-actions">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button class="btn" type="reset">
                                            <i class="icon-undo bigger-110"></i>
                                            Reset重置
                                        </button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button class="btn btn-info submit" type="submit">
                                            <i class="icon-ok bigger-110"></i>
                                            Submit提交
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
            <!-- page specific plugin scripts -->
    <script src="/assets/xshop/jquery.html5-fileupload.js"></script>
    <script src="/assets/xshop/upload.js"></script>
    <script src="/assets/select2/js/select2.js"></script>
    <script src="/assets/js/fuelux/fuelux.spinner.min.js"></script>
    <script src="/assets/kindeditor/kindeditor.js"></script>
    <script src="/assets/kindeditor/lang/zh_CN.js"></script>

    <script type="text/javascript">
        $('#select2').select2();
        $('#select3').select2();
    </script>
    <script>
        KindEditor.ready(function (K) {
            window.editor = K.create('#editor_id');
        });
    </script>
    <script>
        $(function () {
            /*是否显示*/
            $(".ace-switch").on('click', function () {
                $value = $("#is_show").val();
                if ($value == 1) {
                    $("#is_show").val(0);
                } else {
                    $("#is_show").val(1);
                }
            });

            /*必填项*/
            $(".submit").click(function () {
                $value = $(".name").val();
                if ($value == "") {
                    $(".name_display").attr("style", "color: red;");
                    return false;
                }
            });
            $(".name").blur(function () {
                $value = $(this).val();
                if ($value == "") {
                    $(".name_display").attr("style", "color: red;");
                } else {
                    $(".name_display").attr("style", "color: red;display:none");
                }
            });
            $('#spinner2').ace_spinner({
                value: 0,
                min: 0,
                max: 99999,
                step: 100,
                on_sides: true,
                icon_up: 'icon-plus smaller-75',
                icon_down: 'icon-minus smaller-75',
                btn_up_class: 'btn-success',
                btn_down_class: 'btn-danger'
            });

            $('#spinner3').ace_spinner({
                value: 0,
                min: 0,
                max: 9999,
                step: 100,
                on_sides: true,
                icon_up: 'icon-plus smaller-75',
                icon_down: 'icon-minus smaller-75',
                btn_up_class: 'btn-success',
                btn_down_class: 'btn-danger'
            });
            /*上传图片*/
            $('#id-input-file-2').ace_file_input({
                no_file:'No File ...',
                btn_choose:'Choose',
                btn_change:'Change',
                droppable:false,
                onchange:null,
                thumbnail:false
            });

            $('#id-input-file-3').ace_file_input({
                style:'well',
                btn_choose:'Drop files here or click to choose',
                btn_change:null,
                no_icon:'icon-cloud-upload',
                droppable:true,
                thumbnail:'small',
                preview_error : function(filename, error_code) {
                    //name of the file that failed
                    //error_code values
                    //1 = 'FILE_LOAD_FAILED',
                    //2 = 'IMAGE_LOAD_FAILED',
                    //3 = 'THUMBNAIL_FAILED'
                    //alert(error_code);
                }

            }).on('change', function(){
                //console.log($(this).data('ace_input_files'));
                //console.log($(this).data('ace_input_method'));
            });


            //dynamically change allowed formats by changing before_change callback function
            $('#id-file-format').removeAttr('checked').on('change', function() {
                var before_change
                var btn_choose
                var no_icon
                if(this.checked) {
                    btn_choose = "Drop images here or click to choose";
                    no_icon = "icon-picture";
                    before_change = function(files, dropped) {
                        var allowed_files = [];
                        for(var i = 0 ; i < files.length; i++) {
                            var file = files[i];
                            if(typeof file === "string") {
                                //IE8 and browsers that don't support File Object
                                if(! (/\.(jpe?g|png|gif|bmp)$/i).test(file) ) return false;
                            }
                            else {
                                var type = $.trim(file.type);
                                if( ( type.length > 0 && ! (/^image\/(jpe?g|png|gif|bmp)$/i).test(type) )
                                        || ( type.length == 0 && ! (/\.(jpe?g|png|gif|bmp)$/i).test(file.name) )//for android's default browser which gives an empty string for file.type
                                ) continue;//not an image so don't keep this file
                            }

                            allowed_files.push(file);
                        }
                        if(allowed_files.length == 0) return false;

                        return allowed_files;
                    }
                }
                else {
                    btn_choose = "Drop files here or click to choose";
                    no_icon = "icon-cloud-upload";
                    before_change = function(files, dropped) {
                        return files;
                    }
                }
                var file_input = $('#id-input-file-3');
                file_input.ace_file_input('update_settings', {'before_change':before_change, 'btn_choose': btn_choose, 'no_icon':no_icon})
                file_input.ace_file_input('reset_input');
            });

        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>